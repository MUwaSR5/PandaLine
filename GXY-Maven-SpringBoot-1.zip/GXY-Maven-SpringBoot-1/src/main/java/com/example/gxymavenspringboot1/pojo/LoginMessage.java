package com.example.gxymavenspringboot1.pojo;

import lombok.Data;

@Data
public class LoginMessage {

    private String userName;
    private String password;


}

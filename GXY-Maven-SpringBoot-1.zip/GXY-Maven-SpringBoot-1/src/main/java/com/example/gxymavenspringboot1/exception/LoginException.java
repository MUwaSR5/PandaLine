package com.example.gxymavenspringboot1.exception;

public class LoginException extends Exception {
    LoginException(String s) {
        super(s);
    }



}

package com.example.gxymavenspringboot1.pojo;

import lombok.Data;

@Data
public class UserLoginVerify {
    private String cusId;
    private String password;
}

package com.example.gxymavenspringboot1.pojo;

import lombok.Data;

@Data
public class UpdateUserEnter {
    private int id;
    private String cusId;
    private String password;
}

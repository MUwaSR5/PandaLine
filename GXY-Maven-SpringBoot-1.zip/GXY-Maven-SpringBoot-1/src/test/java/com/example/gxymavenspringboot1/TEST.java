package com.example.gxymavenspringboot1;


import lombok.Data;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class TEST
{


    public static void main(String[] args) throws ParseException {

        String time ="2024-08-11 00:00:00";
        System.out.println(time.substring(0,10));




    }
}

package com.example.gxymavenspringboot1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GxyMavenSpringBoot1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
